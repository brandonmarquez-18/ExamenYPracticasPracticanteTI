
//Declaramos función con su nombre y parametro a pedir cuando se llame la función
function sumarNumerosPares(arreglo) {
  //Declarramos la variable "suma" para ir almacenando la suma de los numeros pares
  let suma = 0;
  //Usamos ciclo for para ir recorriendo todo el arreglo
    for (let i = 0; i < arreglo.length; i++) {
//Preguntamos si en el arreglo en la posión "i(0 primer vuelta)" si su resuido es 0 entonces el númro es par
      if (arreglo[i] % 2 === 0) {
        //De ser asi la variable suma va a ser igual a lo que ya tiene más el arrego en la posición "i"
        suma += arreglo[i];
      }
    }
    return suma; //Se retorna el resultado de la suma
  }

  //Definimos nuestro arreglo
const arreglo = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

/*Declaramos una variable para suma de los número pares pero llamando a nuestra función que encuentra
y suma los números pares y le pasamos el parametro que pide que es nuestro arreglo que definimos anteriormente*/
const suma = sumarNumerosPares(arreglo);

//Imprimimos la suma
console.log(suma);//30